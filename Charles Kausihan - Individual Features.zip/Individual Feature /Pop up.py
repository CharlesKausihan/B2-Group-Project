import Tkinter
import tkMessageBox

top = Tkinter.Tk()
def info():
   tkMessageBox.showinfo("Click for more information", "Please fill in the desied search criteria sections in order to conduct a search")

B1 = Tkinter.Button(top, text = "Click for more information", command = info)
B1.pack()

top.mainloop()
