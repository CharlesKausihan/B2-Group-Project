#list of result from searching
resultList=user
#list for make names to be sorted
nameList=[]
#final sorted list
Sorted_Name_List=[]

for n in resultList:
    nameList.append(n[0])



def quicksort(lst):
    if not lst:
        return []
    return (quicksort([x for x in lst[1:] if x <  lst[0]])
            + [lst[0]] +
            quicksort([x for x in lst[1:] if x >= lst[0]]))

unsort_list = nameList
sort_list   = quicksort(unsort_list)

for x in nameList:
        for y in resultList:
            if x!=y[0]:
                pass
            else:
                Sorted_Name_List.append(y)

print(sort_list)
