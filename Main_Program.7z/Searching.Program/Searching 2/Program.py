from Tkinter import *

import tkMessageBox
import sqlite3 as sql


class Labels:
   def __init__(self, root):
      self.root = root

      self.label=Label(root, text='Search Criteria                ',height=2).grid(row=1,column=1,sticky=W)
      self.label=Label(root, text='Location: ').grid(row=2,column=1,sticky=E)
      self.label=Label(root, text='Number of Seats: ').grid(row=3,column=1,sticky=E)
      self.label=Label(root, text='Number of Doors: ').grid(row=4,column=1,sticky=E)
      self.label=Label(root, text='Colour: ').grid(row=5,column=1,sticky=E)
      self.label=Label(root, text='Minimum Price: ').grid(row=6,column=1,sticky=E)
      self.label=Label(root, text='Maximum Price: ').grid(row=6,column=3,sticky=E)
      self.label=Label(root, text='Sort by: ', height=5).grid(row=16,column=2,sticky=E)
      self.label=Label(root, text='Results: ', height=5).grid(row=16,column=1,sticky=W)


class DropDownMenu:
   def __init__(self, root):
      self.root = root
      self.colour = StringVar(root)
      self.location = StringVar(root)
      self.sort = StringVar(root)
      
      #Location
      self.OptionMenu=OptionMenu(self.root, self.location, "Any","", "Birmingham", "Cardiff", "Dublin", "Glasgow", "London", "Manchester").grid(row=2,column=2,sticky=W+E)
      #Colour
      self.OptionMenu=OptionMenu(self.root, self.colour, "Any","", "Black", "Blue", "Green", "Red", "Silver", "White").grid(row=5,column=2,sticky=W+E)
      #Sorting
      self.OptionMenu=OptionMenu(self.root, self.sort, "Any","", "High to Low", "Low to High").grid(row=16,column=3,sticky=W+E)     
      
class Entrys:
   def __init__(self,root):
      self.root = root
      self.entry = Entry(self.root)
      self.minp = StringVar()
      self.maxp = StringVar()
      
      
      #Minimum  
      self.minimumPrice = Entry(textvariable = self.minp).grid(row= 6, column = 2)
      #Maximum
      self.maximumPrice = Entry(textvariable = self.maxp).grid(row= 6, column = 4)
    
class CheckbuttonsAndButtons:
   def __init__(self, root, popup):
      self.root = root
      self.button = Button(self.root)
      self.popup = popup
      self.checkbutton = Checkbutton(self.root)
      self.check1 = 0
      self.check2 = 0

      self.var1 = IntVar()
      self.var2 = IntVar()
      self.var3 = IntVar()
      self.var4 = IntVar()
      self.var5 = IntVar()
      self.var6 = IntVar()
      self.var7 = IntVar()

      noOfSeats2 = Checkbutton ( text= "2", variable = self.var1).grid (row=3,column =2 , sticky = W)
      noOfSeats5 = Checkbutton ( text= "5", variable = self.var2).grid (row=3,column =2 , sticky = N)
      noOfSeats7 = Checkbutton ( text= "7", variable = self.var3).grid (row=3,column =2 , sticky = E)
      noOfSeatsAny = Checkbutton ( text= "Any", variable = self.var4).grid (row=3,column =3 , sticky = E)
        
      noOfDoors3 = Checkbutton ( text= "3", variable = self.var5).grid (row=4,column =2 , sticky = W)
      noOfDoors5 = Checkbutton ( text= "5", variable = self.var6).grid (row=4,column =2 , sticky = N)
      noOfDoorsAny = Checkbutton ( text= "Any", variable = self.var7).grid (row=4,column =3 , sticky = E)
      #More Info Button
      self.button = Button(text="Click for more information", command = self.info).grid(row=1,column=5,sticky=W+E)     


   def getInfo (self):
    
          if  self.var1.get() == 1:
             self.check1 = 2
          elif self.var2.get() == 1:
             self.check1 = 5
          elif self.var3.get() == 1:
             self.check1 = 7
          elif  self.var4.get() == 1:
             self.check1 = 8


          if self.var5.get() == 1:
             self.check2 = 2
          elif self.var6.get() == 1:
             self.check2 = 5
          elif self.var7.get() == 1:
             self.check2 = 8

   def info(self):
      self.popup("Click for more information", "Please fill in the desied search criteria sections in order to conduct a search")

def search(root,drop, entry, checkboxes):
    colour_id = drop.colour.get()
    location_id = drop.location.get()
    checkboxes.getInfo()
    checkboxes.getInfo()
    seat_id = checkboxes.check1
    door_id = checkboxes.check2
    minPrice = entry.minp.get()
    maxPrice = entry.maxp.get()
    
 #   root.quit()
    
    print(colour_id, location_id, minPrice, maxPrice, seat_id ,door_id)
"""
    #Search algorithm for all criteria
    db = sql.connect('Car_Database.sqlite')
    cursor = db.cursor()

    cursor.execute('''SELECT * FROM Cars WHERE Colour=? and Location=? and Seats=? and Doors=? and Price BETWEEN ? AND ?''', (colour_id, location_id, seat_id, door_id, minPrice, maxPrice,))
    user = cursor.fetchall()
    print(user)
    db.close()
"""
class MasterClass():
   def __init__(self, root):
      #root = Tk()
      
      label = Labels(root)
      drop = DropDownMenu (root)

      entry = Entrys(root)
      popup = tkMessageBox.showinfo
      checkboxes = CheckbuttonsAndButtons(root,popup)
      checkboxes.getInfo()

      button = Button(root, text="Search", command=lambda:search(root,drop,entry,checkboxes)).grid(row=15,column=3,sticky=W+E)

      ##mainloop()

if __name__ == '__main__':
	sys.exit(MasterClass())    





