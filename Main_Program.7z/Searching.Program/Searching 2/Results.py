from Tkinter import *

listbox = 0
sort = 0

def sorting(frame1):
      global listbox, sort
      sort = StringVar()
      label = Label(frame1, text = 'Sort Order:  ')
      label.pack()
      optionMenu = OptionMenu(frame1, sort, "High to Low", "Low to High")
      optionMenu.pack()
      #listbox.delete(0, END)

def do():
      print "value is", sort.get()

def listo(frame2, myList):
      global listbox
      listbox = Listbox(frame2)
      for x in myList:
            listbox.insert(END, str(x))
            
      makeScrollbar(frame2, listbox)
      listbox.pack(fill = X)
      sorting(frame2)

def makeScrollbar(frame2, ulistbox):
      scrollbar = Scrollbar(frame2)
      ulistbox.config(yscrollcommand=scrollbar.set)
      scrollbar.config(command=ulistbox.yview)
      scrollbar.pack(side=RIGHT, fill= Y)

def print_Results(myList):
      root = Tk()
      root.geometry("220x280")
      frame1 = Frame(root).grid(row =1, column = 1)
      b = Button(frame1, text="Done", command=lambda:root.destroy())
      b.pack()
      b1 = Button(frame1, text="Change", command=do)
      b1.pack()


      frame2 = Frame(root).grid(row =2, column = 1)
      listo(frame2, myList)

      
      
      #sorting(frame1)
      
      mainloop()



def main():
    root = Tk()
    listo(root)
    mainloop()



if __name__ == '__main__':
      sys.exit(print_Results([123,42345,45345354,64,5645,64567,47,4756,756,234,42,44,234,2342,42,3423,4,423,4234,234,23,42]))
      #sys.exit(main())
"""
root = Tk()
#fame created to group listbox and scroll widgets
frame1 = Frame(root)

frame1.grid(row=1, column = 1)
#frame1.pack(side = BOTTOM)

label = Label(root, text = "***\\\TEXT///***").grid(row = 1, column =2)



scrollbar = Scrollbar(frame1)
scrollbar.pack(side=RIGHT, fill= Y)

listbox = Listbox(frame1, yscrollcommand=scrollbar.set, height = 10, width = 20)

#can be deleted. used to show the scroll function 
for i in range(1000):
    listbox.insert(END, str(i))


listbox.pack(side=LEFT, fill= BOTH)
scrollbar.config(command=listbox.yview)

mainloop()
"""
