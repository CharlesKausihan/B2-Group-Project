from Tkinter import *
listbox = 0

def Results_main(myList):
    root = Tk()
    Results(root, myList)

    mainloop()
    
class Results():
      def __init__(self,root,myList):

            root.geometry("400x240")
            self.frame1 = Frame(root).grid(row =1, column = 1)
            self.frame2 = Frame(root).grid(row =2, column = 1)

            self.b1 = Button(self.frame1, text="Change", command=self.testpr)
            self.b1.pack()

            self.label = Label(self.frame1, text = 'Sort Order:  ')
            self.label.pack()

            self.sort = StringVar(root)
            self.optionMenu = OptionMenu(self.frame1, self.sort, "High to Low", "Low to High")
            self.optionMenu.pack()

            self.listo(self.frame2, myList)

            
      def testpr(self):
            print "value is", self.sort.get()

      def listo(self, frame2, myList):
            global listbox
            listbox = Listbox(self.frame2)
            for x in myList:
                  listbox.insert(END, str(x))
            
            self.makeScrollbar(self.frame2, listbox)
            listbox.pack(fill = X)
            #sorting(self.frame2)

      def makeScrollbar(self, frame2, ulistbox):
            scrollbar = Scrollbar(frame2)
            ulistbox.config(yscrollcommand=scrollbar.set)
            scrollbar.config(command=ulistbox.yview)
            scrollbar.pack(side=RIGHT, fill= Y)
            
"""
listbox = 0
sort = 0



def sorting(frame1):
      global listbox, sort
      sort = StringVar()
      label = Label(frame1, text = 'Sort Order:  ')
      label.pack()
      optionMenu = OptionMenu(frame1, sort, "High to Low", "Low to High")
      optionMenu.pack()
      #listbox.delete(0, END)

def do():
      print "value is", sort.get()

def listo(frame2, myList):
      global listbox
      listbox = Listbox(frame2)
      for x in myList:
            listbox.insert(END, str(x))
            
      makeScrollbar(frame2, listbox)
      listbox.pack(fill = X)
      sorting(frame2)

def makeScrollbar(frame2, ulistbox):
      scrollbar = Scrollbar(frame2)
      ulistbox.config(yscrollcommand=scrollbar.set)
      scrollbar.config(command=ulistbox.yview)
      scrollbar.pack(side=RIGHT, fill= Y)

def print_Results(myList):
      root = Tk()
      root.geometry("220x280")
      frame1 = Frame(root).grid(row =1, column = 1)

      b1 = Button(frame1, text="Change", command=do)
      b1.pack()


      frame2 = Frame(root).grid(row =2, column = 1)
      listo(frame2, myList)

      
      
      #sorting(frame1)
      
      mainloop()

"""

if __name__ == '__main__':
      root = Tk()
      myList = [123,42345,45345354,64,5645,64567,47,4756,756,234,42,44,234,2342,42,3423,4,423,4234,234,23,42]
      gui = Results(root, myList)
      mainloop()
      #sys.exit(print_Results([123,42345,45345354,64,5645,64567,47,4756,756,234,42,44,234,2342,42,3423,4,423,4234,234,23,42]))

      

