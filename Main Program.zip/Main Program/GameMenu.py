#import all of the files from the main game 
from Tkinter import *
import tkMessageBox
from MapGui2 import *
from Program import *
from Results import *


#the labels that will appear on the menu
class Title:
   def __init__(self, root):
      self.root = root

      self.label = Label(root, text="Car Bargain Hunt", bg="darkgrey", fg="blue", font=("Garamond", 20, "bold italic"),height=2).grid(row=4,column=5,sticky=N)
      self.label = Label(root, text="Find the right car for you", bg="darkgrey", fg="black", font=("Garamond", 16, "italic"),height=2).grid(row=6,column=5,sticky=N)
     
#The buttons on the menu 
class Buttons:
   def __init__(self, root, popup):
      self.root = root
      self.button = Button(self.root)
      self.popup = popup
      #Quit Button
      self.button = Button(text="Quit", bg="darkgrey", fg="red", command=root.destroy).grid(row=15,column=3,sticky=W+E)
      #Help Button
      self.button = Button(text="Help", bg="darkgrey", fg="green", command=self.info).grid(row=15,column=10,sticky=W+E)
      #Start Button
      self.button = Button(text="Start", command=self.new_window, font=("Helvetica",11,"bold"), bg="darkgrey", height=2).grid(row=15,column=5,sticky=W+E)

   #Function to display a help message
   def info(self):
      self.popup("Help", "Use the search criteria to search for the car you want.")

   #Function to take you to the main game when clicked. 
   def new_window(self):
      execfile("Program.py")
      


      
   
def main():
	root = Tk()
	label = Title(root)
	popup = tkMessageBox.showinfo
	button = Buttons(root, popup)
	root.title("Virtual Robot Bargain Hunt")
	root.configure(background="darkgrey")
	
	root.mainloop()

if __name__ == '__main__':
	sys.exit(main())
