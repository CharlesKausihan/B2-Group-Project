from Tkinter import *

listbox = 0
output = []
output_r = []
hasPreList = False 


def Results_main(root):
    
    global results
    r = Results(root, results)
    
class Results():
    def __init__(self,root,myList):
        root.geometry("400x240")
        root.title("Results")
        self.frame1 = Frame(root).grid(row =1, column = 1)
        self.frame2 = Frame(root).grid(row =2, column = 1)
        global listbox
        listbox = Listbox(self.frame2)

        self.scrollbar = Scrollbar(self.frame2)
        self.makeScrollbar(listbox)

        self.b1 = Button(self.frame1, text="Change", command=self.state)
        self.b1.pack()

        self.label = Label(self.frame1, text = 'Sort Order:  ')
        self.label.pack()

        self.sort = StringVar()
        self.optionMenu = OptionMenu(self.frame1, self.sort, "High to Low", "Low to High")
        self.optionMenu.pack()
        root.mainloop()


    
    def state(self):
        global hasPreList
        global listbox
        if hasPreList == True:
            listbox.delete(0, END)
            
    
        if self.sort.get() == "Low to High":
            global output
            self.listo(output)
            hasPreList = True
        elif self.sort.get() == "High to Low":
            global output_r
            self.listo(output_r)
            hasPreList = True

    def listo(self, myList):            
        global listbox
        
        listbox.delete(0, END)
        for x in myList:
              listbox.insert(END, str(x))
        

        listbox.pack(fill = X)            
        #sorting(self.frame2)

    def makeScrollbar(self, ulistbox):
        
        ulistbox.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=ulistbox.yview)
        self.scrollbar.pack(side=RIGHT, fill= Y)
    
class Sorting:
    def __init__(self, user):
        self.resultList = user

        self.priceList=[]
        self.Sorted_Results_List=[]
        self.Sorted_Results_List2=[]

        

        self.elementSearch()

    def getResults (self):
        global output
        return output

    def getResults_r (self):
        global output_r
        return output_r

    def elementSearch(self):
        for n in self.resultList:

            self.priceList.append(n[6])

        self.checkLen()

    def checkLen(self):
        if len(self.priceList)<=5:
            '''call selection sort function
            if the length o the list is 5 or less '''
            self.selectionSort()
        elif len(self.priceList)>5 and len(self.priceList)<=25:
                '''call insetion sort function
                if the list is longer than 5 but less than 25 '''


    #selection sort algorithm
    def selectionSort(self):
        for i in range(len(self.priceList)-1,0,-1):
            maxPos=0
            for n in range(1,i+1):
                if self.priceList[n]>self.priceList[maxPos]:
                   maxPos = n

            j = self.priceList[i]
            self.priceList[i] = self.priceList[maxPos]
            self.priceList[maxPos] = j
        self.finalSort()   
        

    #insertion sort algorithm
    def insertionsort(self):
        for i in range(1, len( elf.priceList)):
            t = self.priceList[i]
            j = i
            while j > 0 and t < seq[j - 1]:
                self.priceList[j] = self.priceList[j - 1]
                j -= 1
                self.priceList[j] = t
        self.finalSort()

    #using sorted priceList and unsorted resultList to form sorted results list 
    def finalSort(self):
        for x in self.priceList:
            for y in self.resultList:
                if x!=y[6]:
                    pass
                else:
                    self.Sorted_Results_List.append(y)
                    self.Sorted_Results_List2.append(y)
                    self.Sorted_Results_List2.reverse()
        global output
        global output_r
        output = self.Sorted_Results_List
        output_r = self.Sorted_Results_List2
