from Tkinter import *
import time
from Program import *

def cross_make(location):
    root = Tk()
    Gui(root, location)
    mainloop()
    
class Gui:
    def __init__(self, root, location):
        self.root = root
        self.root.title("Animation")
        

        self.frame1 = Frame(self.root)
        self.frame1.grid(row =1,column = 1)
        
        self.frame2 = Frame(self.root)
        self.frame2.grid(row =2,column = 1)
        
        self.button = Button(self.frame1,text="Move",command=self.movement)
        self.button.grid()
        
        self.canvas = Canvas(self.frame2,width = 500, height = 640, bg = 'red')
        self.canvas.grid()
        
        self.gif1 = PhotoImage(file = 'Map.gif')
        self.gif2 = PhotoImage(file = 'Stickman.gif')

        
    # put gif image on canvas
    # pic's upper left corner (NW) on the canvas is at x=50 y=10

    
        self.canvas.create_image(0, 0, image = self.gif1, anchor = NW)
        self.robot = self.canvas.create_image(10, 590, image = self.gif2, anchor = NW)
        self.location = str(location)    
        
    def animation(self,destX, destY):
        """ Code to animate travel between the different locations."""
        canvas = self.canvas
        robotX, robotY = canvas.coords(self.robot)
        while robotX != destX or robotY != destY:
            if robotX < destX and robotY < destY:
                canvas.coords(self.robot, robotX+1, robotY+1)
            elif robotX > destX and robotY < destY:
                canvas.coords(self.robot, robotX-1, robotY+1)
            elif robotX < destX and robotY > destY:
                canvas.coords(self.robot, robotX+1, robotY-1)
            elif robotX > destX and robotY > destY:
                canvas.coords(self.robot, robotX-1, robotY-1)
            elif robotX < destX:
                canvas.coords(self.robot, robotX+1, robotY)
            elif robotY < destY:
                canvas.coords(self.robot, robotX, robotY+1)
            elif robotX > destX:
                canvas.coords(self.robot, robotX-1, robotY)
            elif robotY > destY:
                canvas.coords(self.robot, robotX, robotY-1)
            canvas.update()
            robotX, robotY = canvas.coords(self.robot)
            time.sleep(0.005)
        self.root.destroy()
        
            
    def movement(self):
        """ Function that moves the robot to the specified locations."""
        if self.location == "London" or self.location == "london" or self.location == "Birmingham" or self.location == "birmingham" or self.location == "Manchester" or self.location == "manchester" or self.location == "Cardiff" or self.location == "cardiff" or self.location == "glasgow" or self.location == "Glasgow" or self.location == "Dublin" or self.location == "dublin":
            canvas = self.canvas
            # Move to Birmingham
            if self.location == "Birmingham" or self.location == "birmingham":
                self.animation(360,410)

            # Move to Manchester    
            elif self.location == "Manchester" or self.location == "manchester":
                self.animation(325,350)

            # Move to Cardiff
            elif self.location == "Cardiff" or self.location == "cardiff":
                self.animation(275,450)

            # Move to Dublin
            elif self.location == "Dublin" or self.location == "dublin":
                self.animation(150,360)

            # Move to London
            elif self.location == "London" or self.location == "london":
                self.animation(380,475)
                
            # Move to Glasgow
            elif self.location == "Glasgow" or self.location == "glasgow":
                self.animation(260,220)
        else:
              print("Not A Valid Location")

if __name__ == '__main__':
    root = Tk() 
    g = Gui(root,"Glasgow")
    
    mainloop()
