from Tkinter import *
from MapGui2 import *
from Results import *
from GameMenu import *
import sqlite3 as sql

location_id = 0 #global
user = 0

class GUI:
   def __init__(self, root):
      self.root = root
      #self.frame = Frame(self.root)
      #self.frame.pack()
      
      #Labels
      self.label=Label(root, text='Search Criteria                ',height=2).grid(row=1,column=1,sticky=W)
      self.label=Label(root, text='Location: ').grid(row=2,column=1,sticky=E)
      self.label=Label(root, text='Number of Seats: ').grid(row=3,column=1,sticky=E)
      self.label=Label(root, text='Number of Doors: ').grid(row=4,column=1,sticky=E)
      self.label=Label(root, text='Colour: ').grid(row=5,column=1,sticky=E)
      self.label=Label(root, text='Minimum Price: ').grid(row=6,column=1,sticky=E)
      self.label=Label(root, text='Maximum Price: ').grid(row=6,column=3,sticky=E)

      #Search Button
      button = Button(root, text="Search", command=lambda:self.search(root)).grid(row=15,column=3,sticky=W+E)

      #Dropdown Menus
      self.colour = StringVar()
      self.location = StringVar()
      #Location
      self.OptionMenu=OptionMenu(self.root, self.location, "Any","", "Birmingham", "Cardiff", "Dublin", "Glasgow", "London", "Manchester").grid(row=2,column=2,sticky=W+E)
      #Colour
      self.OptionMenu=OptionMenu(self.root, self.colour, "Any","", "Black", "Blue", "Green", "Red", "Silver", "White").grid(row=5,column=2,sticky=W+E)   
      

      #Entries/Textboxes
      self.entry = Entry(self.root)
      self.minp = StringVar()
      self.maxp = StringVar()
      
      #Minimum  
      self.minimumPrice = Entry(textvariable = self.minp).grid(row= 6, column = 2)
      #Maximum
      self.maximumPrice = Entry(textvariable = self.maxp).grid(row= 6, column = 4)
    

      #Checkbuttons
      self.button = Button(self.root)
      self.checkbutton = Checkbutton(self.root)
      self.check1 = 0
      self.check2 = 0

      self.var1 = IntVar()
      self.var2 = IntVar()
      self.var3 = IntVar()
      self.var4 = IntVar()
      self.var5 = IntVar()
      self.var6 = IntVar()
      self.var7 = IntVar()

      noOfSeats2 = Checkbutton ( text= "2", variable = self.var1).grid (row=3,column =2 , sticky = W)
      noOfSeats5 = Checkbutton ( text= "5", variable = self.var2).grid (row=3,column =2 , sticky = N)
      noOfSeats7 = Checkbutton ( text= "7", variable = self.var3).grid (row=3,column =2 , sticky = E)
      noOfSeatsAny = Checkbutton ( text= "Any", variable = self.var4).grid (row=3,column =3 , sticky = E)
        
      noOfDoors3 = Checkbutton ( text= "3", variable = self.var5).grid (row=4,column =2 , sticky = W)
      noOfDoors5 = Checkbutton ( text= "5", variable = self.var6).grid (row=4,column =2 , sticky = N)
      noOfDoorsAny = Checkbutton ( text= "Any", variable = self.var7).grid (row=4,column =3 , sticky = E)
   


   def setCheckInfo (self):
    
          if  self.var1.get() == 1:
             self.check1 = 2
          elif self.var2.get() == 1:
             self.check1 = 5
          elif self.var3.get() == 1:
             self.check1 = 7
          elif  self.var4.get() == 1:
             self.check1 = 8


          if self.var5.get() == 1:
             self.check2 = 2
          elif self.var6.get() == 1:
             self.check2 = 5
          elif self.var7.get() == 1:
             self.check2 = 8


   #getting information from the widgets
   def search(self,root):
      global location_id
      colour_id = self.colour.get()
      location_id = self.location.get()

      self.setCheckInfo()

      seat_id = self.check1
      door_id = self.check2
      minPrice = self.minp.get()
      maxPrice = self.maxp.get()

      self.database(colour_id,location_id, seat_id, door_id, minPrice, maxPrice)
      self.root.destroy()

   #passing info to the dtabase 
   def database(self, colour_id,location_id, seat_id, door_id, minPrice, maxPrice):
      #Search algorithm for all criteria
      db = sql.connect('Car_Database.sqlite')
      cursor = db.cursor()

      cursor.execute('''SELECT * FROM Cars WHERE Colour=? and Location=? and Seats=? and Doors=? and Price BETWEEN ? AND ?''', (colour_id, location_id, seat_id, door_id, minPrice, maxPrice,))
      global user
      user = cursor.fetchall()
      #print(user)
      
      db.close()

class MasterClass():
   def __init__(self):
      #window 1
      root = Tk()
      root.title("Search Criteria")
      gui = GUI(root)
      mainloop()

      #once window exit
      #window 2 
      cross_make(location_id) # call animation file
      #wait till exit

      #Run results window
      root = Tk()
      s = Sorting(user)
      r = Results(root, s.getResults())
      





if __name__ == '__main__':
	sys.exit(MasterClass())    

